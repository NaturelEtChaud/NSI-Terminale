#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from PIL import Image 				# pour travailler sur des images numériques
photo = Image.open("chouchou0.jpg") 	# pour charger la photo
info = photo._getexif() 				# récupération des métadonnées EXIF