#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def mystere(tab1, tab2):
	liste = []
	i, j = 0, 0
	while i < len(tab1) and j < len(tab2) :
		if tab1[i] < tab2[j] :
			liste.append(tab1[i])
			i = i + 1
		else :
			liste.append(tab2[j])
			j = j + 1
	if i != len(tab1):
		for k in range(i,len(tab1)):
			liste.append(tab1[k])
	elif j!= len(tab2):
		for k in range(j,len(tab2)):
			liste.append(tab2[k])
	return liste