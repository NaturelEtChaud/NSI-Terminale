#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from random import randint

T = [randint(-100,100) for i in range(100)]

def tri_bulles(tab):
    """
    Entrée :
        tab est un tableau d'entiers
    Sortie :
        tri est un tableau trié dans l'ordre croissant contenant exactement les mêmes valeurs que tab
    """
    # on effectue une copie du tableau 
    tri = tab.copy()
    pass
    return tri
    
assert tri_bulles(T) == sorted(T), "le tableau n'est pas trié"
