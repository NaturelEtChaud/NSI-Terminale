#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
url='http://api.open-notify.org/iss-now.json'
# ligne 7 pour contourner le proxy du lycée
# à supprimer à la maison ! (modifier aussi la ligne 8)
proxy_lycee={'http':'http://172.30.137.29:3128'}
lecture=requests.get(url,proxies=proxy_lycee)
ouEstISS=lecture.json()