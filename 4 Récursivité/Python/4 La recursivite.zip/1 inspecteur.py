# import sys
# sys.setrecursionlimit(2000)

def inspecteurJuve():
    print("Mais ce n'est pas moi !")
    inspecteurJuve()
