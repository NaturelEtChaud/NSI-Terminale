#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from random import randint

liste_grades = ["élève gendarme", "gendarme", "maréchal des logis", "adjudant", "adjudant chef", "major", "élève officier", "sous-lieutenant", "lieutenant", "capitaine", "commandant", "lieutenant colonel", "colonel", "général"]
 

class Gendarme :
    '''
    La super classe des gendarmes à Saint-Tropez
    '''
    
    # constructeur
    def __init__(self, nom, grade):
        self.nom = nom
        self.grade = grade
        self.qi = randint(40,80)
        self.nb_pv = 0
        
    # méthodes
    def get_nom(self):
        ''' accesseur pour l'attribut nom '''
        return self.nom
    
    def set_nom(self, nouveau_nom):
        ''' mutateur pour l'attribut nom '''
        assert isinstance(nouveau_nom,str), "le nouveau nom n'est pas une chaîne de caractères"
        self.nom = nouveau_nom