# -*- coding: utf-8 -*-
"""
Created on Tue Sep  8 14:47:03 2020

@author: Laurent Chaudet
"""

from maFraction import Fraction

A = Fraction(1,3)
B = Fraction(1,2)
print(A,"+", B,"=", A+B)
